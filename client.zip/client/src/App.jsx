import { Routes, Route, useLocation } from "react-router-dom";

import Home from "./pages/Home";
import Doctors from "./pages/Doctor";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Booking from "./pages/Booking";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import MyPrescriptions from "./pages/MyPrescriptions";
import MyAppointments from "./pages//MyAppointments";
import Gallery from "./pages/Gallery";
import Profile from "./pages/Profile";


function App() {
  const location = useLocation();

  const hideFooterRoutes = ["/login", "/signup"];
  const shouldHideFooter = hideFooterRoutes.includes(location.pathname);

  return (
    <>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/doctors" element={<Doctors />} />
        <Route path="/book/:id" element={<Booking />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/my-prescriptions" element={<MyPrescriptions />} />\
        <Route path="/my-appointments" element={<MyAppointments />} />
        <Route path="/gallery" element={<Gallery />} />
        
        <Route path="/profile" element={<Profile />} />

      </Routes>

      {!shouldHideFooter && <Footer />}
    </>
  );
}

export default App;
